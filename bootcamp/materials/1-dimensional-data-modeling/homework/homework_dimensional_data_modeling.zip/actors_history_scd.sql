create table actors_history_scd
(
	actorid text,
	actor text,
	quality_class quality_class,
	is_active boolean,
	start_year integer,
	end_year integer,
	current_year integer,
	PRIMARY KEY(actorid, start_year)
);