CREATE TABLE host_activity_reduced
(
    month_start DATE,
    host TEXT,
    hit_array BIGINT[],
    unique_visitors BIGINT[],
    PRIMARY KEY (month_start, host)
);